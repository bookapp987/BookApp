// import { Book } from './book';

// export class ShoppingCart {
//     book: Book;
//     quantity: number;
// }
