export class User {
    userId: number;
    firstName: string;
    lastName: number;
    EmailID:string;
    username: string;
    userTypeId: number;
    isLoggedIn: boolean;
}
