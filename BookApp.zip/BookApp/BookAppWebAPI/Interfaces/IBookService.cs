﻿using BookAppClass.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookAppWebAPI.Interfaces
{
    public interface IBookService
    {
        List<Book> GetAllBooks();
        int AddBook(Book book);
        int UpdateBook(Book book);
        Book GetBookData(int bookId);
        string DeleteBook(int bookId);
        List<Category> GetCategories();
        List<Book> GetSimilarBooks(int bookId);
        List<Book> GetBooksAvailableInWishlist(string wishlistID);
    }
}
