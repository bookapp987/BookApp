import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class RecommendationsService {

  key = "AIzaSyAstMbHQjAKLOC3B_g3jbdj-4YeVhcQb_c";
 

  booklist: any;
  favouriteArticle: any;

  constructor(private httpClient: HttpClient,
              private authService:AuthenticationService) {   }

  getrecommendation() 
  {
    return this.httpClient.get(
      `https://www.googleapis.com/books/v1/volumes?q=books&maxResults=39&keyes&key=${this.key}`
    );
  }

  
}
