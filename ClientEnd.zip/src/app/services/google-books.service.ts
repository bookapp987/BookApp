import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { BooksAPI } from '../models/bookAPI';

@Injectable({
  providedIn: 'root'
})
export class GoogleBooksService {

  private API_PATH = 'https://www.googleapis.com/books/v1/volumes';

  constructor(private http: HttpClient) { }

  search(query: string): Observable<BooksAPI[]> {
    return this.http
      .get<{ items: BooksAPI[] }>(`${this.API_PATH}?q=${query}`)
      .pipe(map(books => books.items || []));
  }

  getById(volumeId: string): Observable<BooksAPI> {
    return this.http.get<BooksAPI>(`${this.API_PATH}/${volumeId}`);
  }
}
