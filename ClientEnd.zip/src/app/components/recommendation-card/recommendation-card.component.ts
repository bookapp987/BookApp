// import { Component, Input, OnInit } from '@angular/core';
// import { WishlistService } from '../../services/wishlist.service';
// import { BooksAPI } from 'src/app/models/bookAPI';

// @Component({
//   selector: 'app-recommendation-card',
//   templateUrl: './recommendation-card.component.html',
//   styleUrls: ['./recommendation-card.component.scss']
// })
// export class RecommendationCardComponent implements OnInit {

//   @Input()
//   public bookItem: BooksAPI = new BooksAPI;


 

//   constructor() { }
 
  

//   ngOnInit(): void {
//   }


  

// }
