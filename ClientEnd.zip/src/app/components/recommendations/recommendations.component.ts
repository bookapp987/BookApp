// import { Component, OnInit } from '@angular/core';
// import { BooksAPI } from 'src/app/models/bookAPI';
// import { RecommendationsService } from 'src/app/services/recommendations.service';

// @Component({
//   selector: 'app-recommendations',
//   templateUrl: './recommendations.component.html',
//   styleUrls: ['./recommendations.component.scss']
// })
// export class RecommendationsComponent implements OnInit {

//   public errorMessage = '';

//   /// property for storing fetch list of news
//   public bookList: Array<BooksAPI> = [];

//   constructor(public recomendationservice : RecommendationsService) { }

//   ngOnInit(): void {

//     this.recomendationservice.getrecommendation()
//     .subscribe((response : any ) => {
      
//       // console.log(response.items);
//       // console.log(response.items[0].volumeInfo.title);
//       //console.log(response.items[]);

//       if (response['items'] !== undefined &&        
//         response['items'].length > 0) {
//         this.bookList = [...response['items']];
//       }
//     },
//     error => {
//       console.log(error);
//       if (error.status === 404) {
//         this.errorMessage = 'Unable to access news server to fetch news';
//       } else if (error.status === 403){
//         this.errorMessage = 'Unauthorized Access !!!';
//       } else{
//         this.errorMessage = 'Internal Server Error, Please Try Again Later';
//       }
//     });

//   }
// }
