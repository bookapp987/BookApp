﻿using BookAppClass.Models;
using BookAppWebAPI.Controllers;
using BookAppWebAPI.Interfaces;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;


namespace BookAppTest
{
    class LoginUnitTest
    {
        [Test]
        public void LoginShouldSuccess()
        {
            UserMaster user = new UserMaster { Username = "admin", Password = "password@123" };
            var mockService = new Mock<IUserService>();
            var config = new Mock<IConfiguration>();
            mockService.Setup(svc => svc.AuthenticateUser(user)).Returns(user);
            var controller = new LoginController(config.Object, mockService.Object);
            var actual = controller.Login(user);
            Assert.AreEqual(actual,user);

        }
    }
}
