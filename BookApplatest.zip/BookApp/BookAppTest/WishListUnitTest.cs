﻿using BookAppClass.Models;
using BookAppWebAPI.Controllers;
using BookAppWebAPI.Interfaces;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;

namespace BookAppTest
{
    class WishListUnitTest
    {
        [Test]
        public void GetUserWishlistSuccess()
        {
            //int userId = 1;
            //var mockwishlistService = new Mock<IWishlistService>();
            //var mockbookService = new Mock<IBookService>();
            //var mockuserService = new Mock<IUserService>();
            //mockwishlistService.Setup(x => x.GetWishlistId(userId)).Returns();
            //var controller = new WishlistController(mockwishlistService.Object, mockbookService.Object, mockuserService.Object);
            //Assert.AreEqual();
        }

        [Test]
        public void ClearWishlistSuccess()
        {
            int userId = 1;
            var mockwishlistService = new Mock<IWishlistService>();
            var mockbookService = new Mock<IBookService>();
            var mockuserService = new Mock<IUserService>();
            mockwishlistService.Setup(x => x.ClearWishlist(userId)).Returns(0);
            var controller = new WishlistController(mockwishlistService.Object, mockbookService.Object, mockuserService.Object);
            var actual = controller.Delete(userId);
            Assert.AreEqual(actual,0);
        }
    }
}
