﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookManagementWebApi.Interfaces;
using BookManagementWebApi.Models;

namespace BookManagementWebApi.DataAccessLayer
{
    public class UserDataAccessLayer : IUserService
    {
        readonly BookManagementContext _dbContext;

        public UserDataAccessLayer(BookManagementContext dbContext)
        {
            _dbContext = dbContext;
        }

        public User AuthenticateUser(User loginCredentials)
        {
            User user = new User();

            var userDetails = _dbContext.Users.FirstOrDefault(
                u => u.Username == loginCredentials.Username && u.Password == loginCredentials.Password
                );

            if (userDetails != null)
            {

                user = new User
                {
                    Username = userDetails.Username,
                    UserId = userDetails.UserId,
                    //FirstName = userDetails.FirstName,
                    //LastName = userDetails.LastName,
                    //EmailId = userDetails.EmailId,
                    //Password=userDetails.Password,
                    //Gender=userDetails.Gender,
                    UserTypeId = userDetails.UserTypeId
                };
                return user;
            }
            else
            {
                return userDetails;
            }
        }

        public int RegisterUser(User userData)
        {
            try
            {
                userData.UserTypeId = 2;
                _dbContext.Users.Add(userData);
                _dbContext.SaveChanges();
                return 1;
            }
            catch
            {
                throw;
            }
        }

        public bool CheckUserAvailabity(string userName)
        {
            string user = _dbContext.Users.FirstOrDefault(x => x.Username == userName)?.ToString();

            if (user != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool isUserExists(int userId)
        {
            string user = _dbContext.Users.FirstOrDefault(x => x.UserId == userId)?.ToString();

            if (user != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
