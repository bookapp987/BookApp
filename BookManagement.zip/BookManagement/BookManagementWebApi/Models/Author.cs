﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BookManagementWebApi.Models
{
    public partial class Author
    {
        public int AuthorId { get; set; }
        public string AuthorName { get; set; }
    }
}
