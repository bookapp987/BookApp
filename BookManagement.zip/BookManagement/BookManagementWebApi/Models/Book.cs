﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BookManagementWebApi.Models
{
    public partial class Book
    {
        public Book()
        {
            Favourites = new HashSet<Favourite>();
        }

        public int BookId { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string Category { get; set; }
        public string CoverFileName { get; set; }

        public virtual ICollection<Favourite> Favourites { get; set; }
    }
}
