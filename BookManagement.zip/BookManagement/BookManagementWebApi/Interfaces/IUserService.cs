﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookManagementWebApi.Models;

namespace BookManagementWebApi.Interfaces
{
    public interface IUserService
    {
        User AuthenticateUser(User loginCredentials);
        int RegisterUser(User userData);
        bool CheckUserAvailabity(string userName);

        bool isUserExists(int userId);
    }
}
