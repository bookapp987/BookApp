﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BookAppClass.Models
{
    public partial class UserType
    {
        public int UserTypeId { get; set; }
        public string UserTypeName { get; set; }
    }
}
