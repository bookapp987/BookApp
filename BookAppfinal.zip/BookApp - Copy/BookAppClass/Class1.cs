﻿using System;

namespace BookAppClass
{
    public class Class1
    {
    }
}
