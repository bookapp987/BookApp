using BookAppClass.Models;
using BookAppWebAPI.Controllers;
using BookAppWebAPI.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Moq;
using NUnit.Framework;

namespace BookAppTest
{
    public class Tests
    {
        [Test]
        public void RegisterShouldReturnCreated()
        {
            UserMaster user = new UserMaster {UserId=2, FirstName = "Jack", LastName = "Daniel", Gender="Male", Password = "password@123"};
            var mockService = new Mock<IUserService>();
            mockService.Setup(svc => svc.RegisterUser(user)).Returns(1);
            var controller = new UserController(mockService.Object);
            var actual = controller.Post(user);
            Assert.AreEqual(actual,1);
        }

        
        
        [Test]
        public void CheckUserAvailabilitySuccess()
        {
            string username = "John";
            var mockService = new Mock<IUserService>();
            mockService.Setup(svc => svc.CheckUserAvailabity(username)).Returns(true);
            var controller = new UserController(mockService.Object);
            var actual = controller.ValidateUserName(username);
            Assert.AreEqual(actual,true);
        }
    }
}
